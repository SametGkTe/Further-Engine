package shaders;

import lime.utils.Assets;
import flixel.addons.display.FlxRuntimeShader;

class AdjustColorShader extends FlxRuntimeShader
{
  public var hue(default, set):Float;
  public var saturation(default, set):Float;
  public var brightness(default, set):Float;
  public var contrast(default, set):Float;

  public function new()
  {
    super(Assets.getText(Paths.getPath('shaders/adjustColor.frag', TEXT, null,false)));
    // FlxG.debugger.addTrackerProfile(new TrackerProfile(HSVShader, ['hue', 'saturation', 'brightness', 'contrast']));
    hue = 0;
    saturation = 0;
    brightness = 0;
    contrast = 0;
  }

  function set_hue(value:Float):Float
  {
    this.setFloat('hue', value);
    this.hue = value;

    return this.hue;
  }

  function set_saturation(value:Float):Float
  {
    this.setFloat('saturation', value);
    this.saturation = value;

    return this.saturation;
  }

  function set_brightness(value:Float):Float
  {
    this.setFloat('brightness', value);
    this.brightness = value;

    return this.brightness;
  }

  function set_contrast(value:Float):Float
  {
    this.setFloat('contrast', value);
    this.contrast = value;

    return this.contrast;
  }
}
