package mikolka.funkin.utils;
/**
 * A static extension which provides utility functions for Arrays.
 */
class ArrayTools
{
  /*
   * Push an element to the array if it is not already present.
   * @param input The array to push to
   * @param element The element to push
   * @return Whether the element was pushed
   */
  public static function pushUnique<T>(input:Array<T>, element:T):Bool
  {
    if (input.contains(element)) return false;
    input.push(element);
    return true;
  }

  public static function pushMany<T>(input:Array<T>, items:Array<T>):Array<T>
  {
    for(x in items){
      input.push(x);
    }
    return input;
  }

  /**
   * Remove all elements from the array, without creating a new array.
   * @param array The array to clear.
   */
  public inline static function clear<T>(array:Array<T>):Void
  {
    // This method is faster than array.splice(0, array.length)
    array.resize(0);
  }
  	/**
		It returns the index of the first element of the array that matches the predicate function.
		If none is found it returns `-1`.
	**/
	public static function findIndex<T>(array:Array<T>, predicate:T->Bool):Int {
		for (i in 0...array.length)
			if (predicate(array[i]))
				return i;
		return -1;
	}
  /**
   * Create a new array with all elements of the given array, to prevent modifying the original.
   */
  public static function clone<T>(array:Array<T>):Array<T>
  {
    return [for (element in array) element];
  }

  /**
   * Return true only if both arrays contain the same elements (possibly in a different order).
   * @param a The first array to compare.
   * @param b The second array to compare.
   * @return Weather both arrays contain the same elements.
   */
  public static function isEqualUnordered<T>(a:Array<T>, b:Array<T>):Bool
  {
    if (a.length != b.length) return false;
    for (element in a)
    {
      if (!b.contains(element)) return false;
    }
    for (element in b)
    {
      if (!a.contains(element)) return false;
    }
    return true;
  }

}
